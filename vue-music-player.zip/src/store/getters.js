

export const disc = state => state.disc