

export const SET_DISC = 'SET_DISC'