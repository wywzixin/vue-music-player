
const state = {
    disc : {}   //推荐页详情信息
}
export default state